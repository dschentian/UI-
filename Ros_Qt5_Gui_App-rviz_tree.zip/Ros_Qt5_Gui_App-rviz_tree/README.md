## ROS Qt Deskotp GUI App(librviz分支 使用librviz的菜单栏实现图层管理功能)
- Use qt5 to implement the ros robot human-machine interface
- 使用qt5实现ros机器人人机界面



### 一，Features
### 一，功能介绍
#### 1，Add Display
#### 1，新增显示
- The new display can provide a series of functions such as drawing, sweeping, etc.
- 新增显示后可以提供建图、扫图等一系列功能。


### 二，安装教程
### 二，Installation tutorial
#### 1，首先安装ros对qt pkg的支持
#### 1，first install ros support for qt pkg
``` bash
sudo apt-get install ros-melodic-qt-create
```

``` bash
sudo apt-get install ros-melodic-qt-build
```
``` bash
sudo apt-get install qtmultimedia5-dev
```
#### 2，
#### 2，编辑
在catkin_qt目录下打开终端输入qtcreator(重要！否则报错)
qtcreator环境下打开cmklist.txt(注意不是功能包下的）(报错的话关闭多试几次）

#### 3，Compile
#### 3，编译

编辑完后拷贝功能包到catkin_ws/src软件包目录下
catkin_make

#### 4，run
#### 4，运行
``` bash
rosrun cyrobot_rviz_tree cyrobot_rviz_tree
```
***
### LIENSE
### 开源协议
**GNU GPL（GNU General Public License，GNU通用公共许可证）**

